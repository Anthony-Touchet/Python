Hex = "FFFFFF"
red = int(Hex[:2], 16)
green = int(Hex[2:4], 16)
blue = int(Hex[4:], 16)
print(red,green,blue)