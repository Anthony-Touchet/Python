rad = 10
price = 6

slice = price / rad

print(slice)